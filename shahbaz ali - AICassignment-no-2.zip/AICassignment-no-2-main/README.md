# AICassignment-no-2
Assignment no 2 
